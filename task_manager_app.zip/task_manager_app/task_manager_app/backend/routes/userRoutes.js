const express = require("express");
const { adminOnly, protect } = require("../middlewares/authMiddleware");
const { getUsers, getUserById, deleteUser } = require("../controllers/userController");

const router = express.Router();


// Get all users (admin only)
router.get("/", protect, adminOnly, getUsers);

// Get a single user by ID
router.get("/:id", protect, getUserById);

// Delete a user by ID (admin only)
router.delete("/delete-user/:id", protect, adminOnly, deleteUser);

module.exports = router;
