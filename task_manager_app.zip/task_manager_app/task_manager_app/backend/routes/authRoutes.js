const express = require("express");
const {
  registerUser,
  loginUser,
  getUserProfile,
  updateUserProfile,
  sendOtpToEmail,
  verifyOtpAndResetPassword,
} = require("../controllers/authController");

const { protect } = require("../middlewares/authMiddleware");
const upload = require("../middlewares/uploadMiddleware");

const router = express.Router();

// Register/Login
router.post("/register", registerUser);
router.post("/login", loginUser);

// Profile
router.get("/profile", protect, getUserProfile);
router.put("/profile", protect, updateUserProfile);

// Image Upload
router.post("/upload-image", upload.single("image"), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ message: "No file uploaded" });
  }
  const imageUrl = `${req.protocol}://${req.get("host")}/uploads/${req.file.filename}`;
  res.status(200).json({ imageUrl });
});

// Forgot Password - OTP Flow
router.post("/send-otp", sendOtpToEmail);                 // Send OTP
router.post("/verify-otp", verifyOtpAndResetPassword);    // Verify OTP & Reset Password

module.exports = router;
