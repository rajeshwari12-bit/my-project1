const nodemailer = require("nodemailer");

const sendEmail = async (to, subject, html) => {
  const transporter = nodemailer.createTransport({
    service: "gmail",
    auth: {
      user: process.env.EMAIL_USER,         // Your Gmail (e.g. test@gmail.com)
      pass: process.env.EMAIL_PASSWORD,     // App password
    },
  });

  const mailOptions = {
    from: process.env.EMAIL_USER,
    to,
    subject,
    html,
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log("Email sent successfully to", to);
  } catch (err) {
    console.error("Error sending email:", err.message);
    throw new Error("Email sending failed");
  }
};

module.exports = sendEmail;
