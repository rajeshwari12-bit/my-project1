const mongoose = require("mongoose");

const PromptHistorySchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  role: String,
  prompt: String,
  result: Object,
  createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model("PromptHistory", PromptHistorySchema);