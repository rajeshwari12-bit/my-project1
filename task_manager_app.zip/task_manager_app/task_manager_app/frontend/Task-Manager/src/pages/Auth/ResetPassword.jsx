import React, { useState } from "react";
import axiosInstance from "../../utils/axiosInstance";
import toast from "react-hot-toast";
import { useNavigate } from "react-router-dom";

const ResetPassword = () => {
  const [otp, setOtp] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const email = localStorage.getItem("resetEmail");
  const navigate = useNavigate();

  const handleReset = async (e) => {
    e.preventDefault();
    try {
      const res = await axiosInstance.post("/auth/verify-otp", {
        email,
        otp,
        newPassword,
      });
      toast.success(res.data.message);
      localStorage.removeItem("resetEmail");
      navigate("/login");
    } catch (err) {
      toast.error(err.response?.data?.message || "Reset failed");
    }
  };

  return (
    <div className="flex justify-center items-center min-h-screen">
      <form className="bg-white shadow-md p-6 rounded" onSubmit={handleReset}>
        <h2 className="text-xl font-bold mb-4">Reset Password</h2>
        <input
          type="text"
          placeholder="Enter OTP"
          className="border p-2 mb-4 w-full"
          value={otp}
          onChange={(e) => setOtp(e.target.value)}
          required
        />
        <input
          type="password"
          placeholder="New Password"
          className="border p-2 mb-4 w-full"
          value={newPassword}
          onChange={(e) => setNewPassword(e.target.value)}
          required
        />
        <button type="submit" className="bg-green-500 text-white p-2 rounded w-full">
          Reset Password
        </button>
      </form>
    </div>
  );
};

export default ResetPassword;
