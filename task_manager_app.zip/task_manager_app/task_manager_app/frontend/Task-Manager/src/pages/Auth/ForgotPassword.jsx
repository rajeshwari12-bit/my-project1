import React, { useState } from "react";
import axiosInstance from "../../utils/axiosInstance";
import toast from "react-hot-toast";
import { useNavigate } from "react-router-dom";

const ForgotPassword = () => {
  const [email, setEmail] = useState("");
  const navigate = useNavigate();

  const handleSendOtp = async (e) => {
    e.preventDefault();
    try {
      const res = await axiosInstance.post("/auth/send-otp", { email });
      toast.success(res.data.message);
      localStorage.setItem("resetEmail", email);
      navigate("/reset-password");
    } catch (err) {
      toast.error(err.response?.data?.message || "Failed to send OTP");
    }
  };

  return (
    <div className="flex justify-center items-center min-h-screen">
      <form className="bg-white shadow-md p-6 rounded" onSubmit={handleSendOtp}>
        <h2 className="text-xl font-bold mb-4">Forgot Password</h2>
        <input
          type="email"
          placeholder="Enter your registered email"
          className="border p-2 mb-4 w-full"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <button type="submit" className="bg-blue-500 text-white p-2 rounded w-full">
          Send OTP
        </button>
      </form>
    </div>
  );
};

export default ForgotPassword;
